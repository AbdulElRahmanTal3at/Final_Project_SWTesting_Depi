package Tests;

import Base.TestBase;
import org.testng.Assert;
import org.testng.annotations.Test;
import Pages.HomePage;
import Pages.SignupLoginPage;
public class LogoutTest extends TestBase {
    SignupLoginPage signupLoginPage;
    HomePage homePage;
    @Test
    public void testLogoutSuccessfully() {
         homePage = new HomePage(driver);
         signupLoginPage = new SignupLoginPage(driver);
        homePage.navigate();
        homePage.clickSignupLogin();
        signupLoginPage.login("olaalaa@gmail", "123456");
        Assert.assertTrue(signupLoginPage.isLoggedIn(), "Login failed before logout test!");
        homePage.clickLogout();
    }

}

